-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 06, 2013 at 08:44 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `bayar`
--

CREATE TABLE IF NOT EXISTS `bayar` (
  `kode` varchar(5) NOT NULL,
  `tanggal` date NOT NULL,
  `pembayaran` varchar(15) NOT NULL,
  `id` int(4) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=165 ;

--
-- Dumping data for table `bayar`
--

INSERT INTO `bayar` (`kode`, `tanggal`, `pembayaran`, `id`) VALUES
('ID001', '2013-02-06', '9000000', 164);

-- --------------------------------------------------------

--
-- Table structure for table `buruh`
--

CREATE TABLE IF NOT EXISTS `buruh` (
  `kode` varchar(5) NOT NULL,
  `buruh` varchar(15) NOT NULL,
  `bonus` varchar(15) NOT NULL,
  `id` int(4) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;

--
-- Dumping data for table `buruh`
--

INSERT INTO `buruh` (`kode`, `buruh`, `bonus`, `id`) VALUES
('ID001', 'buruh 1', '100', 85);

-- --------------------------------------------------------

--
-- Table structure for table `jum`
--

CREATE TABLE IF NOT EXISTS `jum` (
  `kode` varchar(5) NOT NULL,
  `jum` varchar(3) NOT NULL,
  `id` int(4) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jum`
--

INSERT INTO `jum` (`kode`, `jum`, `id`) VALUES
('ID001', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tabel1`
--

CREATE TABLE IF NOT EXISTS `tabel1` (
  `pembayaran` varchar(15) NOT NULL,
  `buruh1` varchar(5) NOT NULL,
  `buruh2` varchar(5) NOT NULL,
  `buruh3` varchar(5) NOT NULL,
  `id` int(4) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tabel1`
--

INSERT INTO `tabel1` (`pembayaran`, `buruh1`, `buruh2`, `buruh3`, `id`) VALUES
('4000000', '30', '40', '30', 27),
('4500000', '30', '40', '30', 28),
('6000000', '50', '40', '10', 29);
